// See jquery-prologue.js for information on why this is necessary.
(function() { if (window.module) module = window.module; })();
